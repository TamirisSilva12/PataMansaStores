package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import lojatenis.LojaTenis;
import lojatenis.ItemCar;
import lojatenis.Tenis;
import java.util.List;

public class TelaProdutos extends javax.swing.JFrame {
    private List<Tenis> listaTenis; // Agora será um atributo da classe
    
    public TelaProdutos() {
        initComponents();
        carregarTabela();
        setTitle("Produtos Disponíveis");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
    private void carregarTabela() {
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
    modelo.setRowCount(0); // Limpa a tabela

    for (Tenis t : LojaTenis.getEstoqueTenis()) {
        modelo.addRow(new Object[]{
            t.getModelo(),
            t.getMarca(),
            t.getPreco(),
            t.getEstoque()
        });
    }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jButton3.setText("jButton3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Modelo", "Marca", "Preço", "Estoque"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setText("Tênis Disponíveis na Loja");

        jButton1.setBackground(new java.awt.Color(102, 0, 102));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 153, 51));
        jButton1.setText("Adicionar ao Carrinho");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(102, 0, 102));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 153, 51));
        jButton2.setText("Voltar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Logo.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(287, 287, 287)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(437, 437, 437)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(463, 463, 463)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 830, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(135, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(170, 170, 170)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2)
                .addContainerGap(227, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    int[] linhasSelecionadas = jTable1.getSelectedRows();

    if (linhasSelecionadas.length == 0) {
        JOptionPane.showMessageDialog(this, "Selecione pelo menos um tênis para adicionar ao carrinho.");
        return;
    }

    for (int linha : linhasSelecionadas) {
        String nome = jTable1.getValueAt(linha, 0).toString();
        String marca = jTable1.getValueAt(linha, 1).toString();
        double preco = Double.parseDouble(jTable1.getValueAt(linha, 2).toString());

        // Pede o tamanho do tênis ao usuário
        String tamanhoStr = JOptionPane.showInputDialog(this, "Informe o tamanho do tênis (ex: 38, 39, 40):");
        if (tamanhoStr == null || tamanhoStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tamanho inválido. Operação cancelada.");
            return;
        }

        int tamanho;
        try {
            tamanho = Integer.parseInt(tamanhoStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Tamanho inválido. Insira um número.");
            return;
        }
        // Solicita a quantidade
        String quantidadeStr = JOptionPane.showInputDialog(this, "Informe a quantidade desejada:");
        if (quantidadeStr == null || quantidadeStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantidade inválida. Operação cancelada.");
            return;
        }

        int quantidade;
        try {
            quantidade = Integer.parseInt(quantidadeStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantidade inválida. Insira um número.");
            return;
        }
        // Busca o tênis original na lista de estoque
        Tenis tenisOriginal = LojaTenis.getEstoqueTenis().get(linha);

        if (!tenisOriginal.temEstoque(quantidade)) {
            JOptionPane.showMessageDialog(this, "Estoque insuficiente para o produto: " + nome);
            return;
        }
        // Atualiza o estoque
        tenisOriginal.atualizarEstoque(quantidade);
        
        // Cria o objeto Tenis personalizado (com tamanho)
        Tenis tenisSelecionado = new Tenis(tenisOriginal.getId(), nome, marca, preco, quantidade);
        tenisSelecionado.setTamanho(tamanho);

        // Adiciona ao carrinho
        ItemCar item = new ItemCar(tenisSelecionado, quantidade, tamanho);
        LojaTenis.adicionarAoCarrinho(item);

        new TelaCarrinho().setVisible(true);
        dispose(); // Fecha a tela atual
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Voltar para a tela anterior
        new TelaLogin().setVisible(true); // ou qualquer outra tela principal
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new TelaProdutos().setVisible(true); // Abre a tela só uma vez
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
