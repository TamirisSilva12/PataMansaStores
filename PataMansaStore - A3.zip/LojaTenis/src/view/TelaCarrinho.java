package view;

import lojatenis.Tenis;
import lojatenis.LojaTenis;
import lojatenis.ItemCar;
import lojatenis.Cliente; 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class TelaCarrinho extends javax.swing.JFrame {

    public TelaCarrinho() {
        initComponents();
        // Verifica se cliente está logado
        Cliente clienteLogado = LojaTenis.getClienteLogado();
        if (clienteLogado == null) {
            JOptionPane.showMessageDialog(this, "Faça login para acessar o carrinho.");
            dispose(); // fecha a tela
            return;
        }
        configurarModeloTabela();
        carregarTabela();
        atualizarTotal();
        setTitle("Seu Carrinho");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    private void configurarModeloTabela() {
        // Cria modelo de tabela com colunas corretas e tipos
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"Modelo", "Marca", "Preço", "Quantidade", "Tamanho"}, 0) {

            Class[] types = new Class[]{
                String.class, String.class, Double.class, Integer.class, Integer.class
            };

            boolean[] canEdit = new boolean[]{
                false, false, false, false, false
            };

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        };
        tableCarrinho.setModel(modelo);
    }
    
    private void carregarTabela() {
    DefaultTableModel modelo = (DefaultTableModel) tableCarrinho.getModel();
    modelo.setRowCount(0); // Limpa tabela

    List<ItemCar> carrinho = LojaTenis.getCarrinho();

    System.out.println("Itens no carrinho: " + carrinho.size());
    for (ItemCar item : LojaTenis.carrinho) {
        System.out.println(item.getTenis().getModelo() + " - Qtd: " + item.getQuantidade() + " - Tamanho: " + item.getTamanho());

        Object[] linha = {
            item.getTenis().getModelo(),
            item.getTenis().getMarca(),
            item.getTenis().getPreco(),
            item.getQuantidade(),
            item.getTamanho()
        };
        modelo.addRow(linha);
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableCarrinho = new javax.swing.JTable();
        labelTotal = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Logo.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel1.setText("Seu Carrinho");

        tableCarrinho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Modelo", "Marca", "Preço", "Quantidade", "Tamanho"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableCarrinho);

        labelTotal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelTotal.setText("Total");

        jButton1.setBackground(new java.awt.Color(102, 0, 102));
        jButton1.setForeground(new java.awt.Color(255, 153, 51));
        jButton1.setText("Finalizar Compra");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(102, 0, 102));
        jButton2.setForeground(new java.awt.Color(255, 153, 51));
        jButton2.setText("Continuar Comprando");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(297, 297, 297)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(281, 281, 281)
                        .addComponent(labelTotal)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(235, 235, 235)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(461, 461, 461)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(235, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(170, 170, 170)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jLabel1)
                .addGap(45, 45, 45)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(labelTotal)
                .addGap(46, 46, 46)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addContainerGap(167, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Voltar para a tela anterior
        new TelaProdutos().setVisible(true); // ou qualquer outra tela principal
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Verifica se o carrinho tem itens
        if (LojaTenis.getCarrinho().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seu carrinho está vazio!");
            return;
        }
        // Vai para a tela de pagamento
        new TelaPagamento().setVisible(true);
        dispose(); // Fecha a tela do carrinho
    }//GEN-LAST:event_jButton1ActionPerformed

    private void atualizarTotal() {
    List<ItemCar> carrinho = LojaTenis.getCarrinho();
    double total = 0;
    for (ItemCar item : carrinho) {
        Tenis tenis = item.getTenis();
        int quantidade = item.getQuantidade();
        total += tenis.getPreco() * quantidade;
    }
    labelTotal.setText(String.format("Total: R$ %.2f", total));
    // Salva o total temporariamente
    LojaTenis.setTotalCarrinho(total);
}
    
    public void atualizarCarrinho() {
    carregarTabela();
    atualizarTotal();
}

    public static void main(String[] args) {
    // Criar um tênis e adicionar no carrinho (para testar)
    Tenis tenis = new Tenis(1, "Tênis Teste", "Marca Teste", 150.0, 10);
    ItemCar itemCar = new ItemCar(tenis, 2, 40);
    LojaTenis.adicionarAoCarrinho(itemCar);

    // Abrir a tela
    java.awt.EventQueue.invokeLater(() -> {
        new TelaCarrinho().setVisible(true);
    });
    
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelTotal;
    private javax.swing.JTable tableCarrinho;
    // End of variables declaration//GEN-END:variables
}
