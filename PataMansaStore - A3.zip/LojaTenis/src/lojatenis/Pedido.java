package lojatenis;

import java.util.List;

public class Pedido {
    // Contador estático usado para gerar um ID único para cada novo pedido
    private static int contador = 1;

    // Atributos do pedido
    private int id;                     // ID único do pedido
    private int quantidade;            // (NÃO UTILIZADO atualmente - pode ser removido ou utilizado no futuro)
    private Cliente cliente;           // Cliente que realizou o pedido
    private List<ItemCar> itens;       // Lista de itens que fazem parte do pedido
    private double total;              // Valor total do pedido (soma dos subtotais dos itens)

    // Construtor: inicializa o pedido com cliente e lista de itens
    public Pedido(Cliente cliente, List<ItemCar> itens) {
        this.id = contador++;              // Atribui um ID único ao pedido
        this.cliente = cliente;           // Armazena o cliente que fez o pedido
        this.itens = itens;               // Armazena os itens do carrinho como itens do pedido
        this.total = calcularTotal();     // Calcula o valor total automaticamente
    }

    // Método privado para calcular o valor total do pedido
    private double calcularTotal() {
        double soma = 0;
        for (ItemCar item : itens) {
            soma += item.getSubtotal();  // Subtotal = preço do tênis * quantidade
        }
        return soma;
    }

    // Getters para acesso externo aos dados do pedido
    public int getId() {
        return id;
    }

    public int getQuantidade() {
        return quantidade; // OBS: Não está sendo usado no momento
    }

    public Cliente getCliente() {
        return cliente;
    }

    public List<ItemCar> getItens() {
        return itens;
    }

    public double getTotal() {
        return total;
    }

    // Método toString para exibir o pedido de forma formatada
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido ").append(id)
          .append(" - Cliente: ").append(cliente.getNome()).append("\n");

        // Adiciona os detalhes de cada item do pedido
        for (ItemCar item : itens) {
            sb.append("  ").append(item).append("\n");
        }

        sb.append("Total: R$").append(String.format("%.2f", total)); // Formata o total com 2 casas decimais
        return sb.toString();
    }
}
