package lojatenis;

public class ItemCar {
    // Cada item do carrinho tem um tênis associado
    private Tenis tenis;
    // Quantidade desse tênis no carrinho
    private int quantidade;
    // Tamanho do tênis escolhido (ex: 38, 40, etc.)
    private int tamanho; // <-- novo campo

    // Construtor que recebe o tênis, a quantidade e o tamanho escolhido
    public ItemCar(Tenis tenis, int quantidade, int tamanho) {
        this.tenis = tenis;
        this.quantidade = quantidade;
        this.tamanho = tamanho;
    }

    // Retorna o objeto Tenis associado a este item
    public Tenis getTenis() {
        return tenis;
    }

    // Retorna a quantidade do tênis no carrinho
    public int getQuantidade() {
        return quantidade;
    }

    // Retorna o tamanho do tênis selecionado
    public int getTamanho() {
        return tamanho;
    }

    // Calcula o subtotal (preço unitário * quantidade)
    public double getSubtotal() {
        return quantidade * tenis.getPreco();
    }
    
    // Permite atualizar a quantidade do item
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    // Representação em texto do item (usado por exemplo em prints ou logs)
    @Override
    public String toString() {
        return tenis.getNome() + " (Tam: " + tamanho + ") x" + quantidade + " = R$" + String.format("%.2f", getSubtotal());
    }
}
