package lojatenis;

public class Tenis {
    // Atributos básicos de um produto (tênis) na loja
    private int id;                    // Identificador único do tênis
    private int estoque;              // Quantidade disponível no estoque
    private int tamanho;              // Tamanho do tênis (ex: 38, 40...)
    private double preco;             // Preço unitário do tênis
    private String modelo;            // Nome do modelo (pode ser editada pelo admin)
    private String marca;             // Marca do tênis (ex: Nike)

    // Construtor padrão da classe - cria um tênis com os dados essenciais
    public Tenis(int id, String modelo, String marca, double preco, int estoque) {
        this.id = id;
        this.modelo = modelo;
        this.marca = marca;
        this.preco = preco;
        this.estoque = estoque;
    }

    // Métodos getters - retornam os dados do tênis
    public int getId() {
        return id;
    }

    public int getEstoque() {
        return estoque;
    }

    public int getTamanho() {
        return tamanho;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }

    public double getPreco() {
        return preco;
    }

    // Retorna o "nome completo" do tênis (marca + modelo)
    public String getNome() {
        return marca + " " + modelo;
    }

    // Setters para alterar os atributos quando necessário
    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    // Verifica se há estoque suficiente para determinada quantidade
    public boolean temEstoque(int quantidade) {
        return estoque >= quantidade;
    }

    // Atualiza o estoque após uma compra, reduzindo a quantidade vendida
    public void atualizarEstoque(int quantidade) {
        if (quantidade > 0 && quantidade <= estoque) {
            this.estoque -= quantidade;
        }
    }

    // Formata a exibição do tênis ao ser impresso
    @Override
    public String toString() {
        return id + ": " + marca + " " + modelo + " - R$" + String.format("%.2f", preco)
               + " (Estoque: " + estoque + ")";
    }
}
