package lojatenis;

import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;


public class LojaTenis {
    // Lista global que armazena todos os pedidos feitos
    private static List<Pedido> historicoPedidos = new ArrayList<>();
    
    // Soma total do carrinho (valor dos itens)
    private static double totalCarrinho;

    // Lista que armazena os produtos no carrinho (modo antigo, não usada diretamente)
    private static List<Tenis> listaCarrinho = new ArrayList<>();

    // Estoque com todos os tênis da loja
    public static List<Tenis> estoqueTenis = new ArrayList<>();

    // Lista com todos os administradores cadastrados
    public static List<Cliente> admins = new ArrayList<>();

    // Lista de produtos (não usada diretamente aqui)
    public static List<Tenis> produtos = new ArrayList<>();

    // Scanner para entrada do usuário via terminal
    static Scanner scanner = new Scanner(System.in);

    // Lista de clientes cadastrados na loja
    static List<Cliente> clientes = new ArrayList<>();

    // Armazena qual cliente está logado no momento
    private static Cliente clienteLogado;
    // Lista de itens no carrinho do cliente logado
    public static List<ItemCar> carrinho = new ArrayList<>(); 

    // Métodos utilitários para acesso e manipulação de listas
    
    public static List<Tenis> getProdutos() {
        return produtos;
    }

    public static List<Pedido> getHistoricoPedidos() {
        return historicoPedidos;
    }
    
    public static Cliente getClienteLogado() {
        return clienteLogado;
    }

    public static void setClienteLogado(Cliente cliente) {
        clienteLogado = cliente;
    }
    public static void adicionarPedidoAoHistorico(Pedido pedido) {
        historicoPedidos.add(pedido);
    }

    public static void setTotalCarrinho(double total) {
        totalCarrinho = total;
    }

    public static double getTotalCarrinho() {
        return totalCarrinho;
    }

    public static void limparCarrinho() {
        carrinho.clear();
    }

    public static List<ItemCar> getCarrinho() {
        return carrinho;
    }

    public static List<Tenis> getEstoqueTenis() {
        return estoqueTenis;
    }

    // Adiciona item ao carrinho diretamente (objeto ItemCar completo)
    public static void adicionarAoCarrinho(ItemCar item) {
        carrinho.add(item);
    }

    // Adiciona tênis ao carrinho com verificação de login e duplicação por ID e tamanho
    public static void adicionarAoCarrinho(Tenis tenis) {
        if (clienteLogado == null) {
            System.out.println("Você precisa estar logado para adicionar ao carrinho.");
            return;
        }

        // Verifica se esse mesmo tênis e tamanho já estão no carrinho
        for (ItemCar item : carrinho) {
            if (item.getTenis().getId() == tenis.getId() && item.getTamanho() == tenis.getTamanho()) {
                item.setQuantidade(item.getQuantidade() + 1); // Apenas aumenta a quantidade
                return;
            }
        }

        // Se não encontrou item igual, adiciona novo com quantidade 1
        carrinho.add(new ItemCar(tenis, 1, tenis.getTamanho()));
    }

    // Método principal que inicia o sistema
    public static void main(String[] args) {
        carregarEstoqueDoArquivo(); // Carrega do arquivo, se existir
        inicializarAdmin();      // Cria um administrador padrão
        System.out.println("Bem-vindo à Loja de Tênis Virtual!");
        menuPrincipal();         // Mostra o menu principal da loja
    }

    // Adiciona tênis pré-definidos ao estoque
    public static void inicializarProdutos() {
        if (!estoqueTenis.isEmpty()) return; // Só adiciona se estiver vazio
        estoqueTenis.add(new Tenis(1, "Air Max", "Nike", 599.90, 60));
        estoqueTenis.add(new Tenis(2, "Ultraboost", "Adidas", 649.90, 55));
        estoqueTenis.add(new Tenis(3, "Flyer", "Puma", 349.90, 78));
        estoqueTenis.add(new Tenis(4, "Gel", "Asics", 429.90, 66));
        estoqueTenis.add(new Tenis(4, "Chuck Taylor", "Converse", 429.90, 62));
        estoqueTenis.add(new Tenis(5, "574", "New Balance", 389.90, 46));
        estoqueTenis.add(new Tenis(6, "Runner X", "Tesla", 499.90, 54));
        estoqueTenis.add(new Tenis(7, "Wave Rider", "Mizuno", 549.90, 49));
        estoqueTenis.add(new Tenis(8, "Sprint Pro", "Olympics", 459.90, 37));
    }

    // Cria um administrador fixo para testes e manutenção
    public static void inicializarAdmin() {
        admins.add(new Cliente(0, "Administrador", "patamansa@loja.com", "#AdminTK", "Loja Central"));
    }

    // Menu principal mostrado para o usuário
    static void menuPrincipal() {
        while (true) {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Login");
            System.out.println("3. Ver Tênis Disponíveis");
            System.out.println("4. Adicionar ao Carrinho");
            System.out.println("5. Ver Carrinho");
            System.out.println("6. Finalizar Pedido");
            System.out.println("7. Ver Histórico de Pedidos");
            System.out.println("8. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer do Scanner

            switch (opcao) {
                case 1:
                    cadastrarCliente();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    listarTenis();
                    break;
                case 4:
                    adicionarAoCarrinho();
                    break;
                case 5:
                    verCarrinho();
                    break;
                case 6:
                    finalizarPedido();
                    break;
                case 7:
                    verHistorico();
                    break;
                case 8:
                    System.out.println("Obrigado por visitar a Loja de Tênis!");
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    // Realiza o login do cliente ou administrador
    public static void login() {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();

        // Verifica se é admin
        for (Cliente a : admins) {
            if (a.autenticar(email, senha)) {
                System.out.println("Login de administrador realizado com sucesso.");
                menuAdmin(); // Acessa menu do admin
                return;
            }
        }

        // Verifica se é cliente
        for (Cliente c : clientes) {
            if (c.autenticar(email, senha)) {
                LojaTenis.setClienteLogado(c);
                System.out.println("Login realizado com sucesso. Bem-vindo, " + c.getNome() + "!");
                return;
            }
        }

        System.out.println("Email ou senha inválidos.");
    }

    // Cadastra um novo cliente na loja
    static void cadastrarCliente() {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();

        int id = clientes.size() + 1;
        clientes.add(new Cliente(id, nome, email, senha, endereco));
        System.out.println("Cadastro realizado com sucesso!");
    }

    // Mostra todos os tênis disponíveis no estoque
    static void listarTenis() {
        System.out.println("\n--- TÊNIS DISPONÍVEIS ---");
        for (Tenis t : estoqueTenis) {
            System.out.println(t);
        }
    }

    // Permite adicionar um tênis ao carrinho (cliente precisa estar logado)
    static void adicionarAoCarrinho() {
        if (clienteLogado == null) {
            System.out.println("Você precisa estar logado para adicionar ao carrinho.");
            return;
        }

        listarTenis();
        System.out.print("Digite o ID do tênis desejado: ");
        int id = scanner.nextInt();
        System.out.print("Quantidade: ");
        int qtd = scanner.nextInt();
        System.out.print("Tamanho (ex: 38, 39, 40...): ");
        int tamanho = scanner.nextInt();
        scanner.nextLine();

        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                if (t.temEstoque(qtd)) {
                    carrinho.add(new ItemCar(t, qtd, tamanho));
                    System.out.println("Tênis adicionado ao carrinho (Tamanho: " + tamanho + ").");
                } else {
                    System.out.println("Estoque insuficiente.");
                }
                return;
            }
        }

        System.out.println("Tênis não encontrado.");
    }

    // Mostra os itens do carrinho atual
    static void verCarrinho() {
        if (carrinho.isEmpty()) {
            System.out.println("Carrinho vazio.");
            return;
        }

        System.out.println("\n--- CARRINHO ---");
        double total = 0;
        for (ItemCar item : carrinho) {
            System.out.println(item);
            total += item.getSubtotal();
        }
        System.out.println("Total: R$" + String.format("%.2f", total));
    }

    // Calcula o valor total dos itens no carrinho
    public static double getValorTotalCarrinho() {
        double total = 0;
        for (ItemCar item : carrinho) {
            total += item.getTenis().getPreco() * item.getQuantidade();
        }
        return total;
    }

    // Mostra opções de pagamento e processa a escolhida
    public static void selecionarMetodoPagamento(double total) {
        System.out.println("\n--- MÉTODO DE PAGAMENTO ---");
        System.out.println("1. Cartão de Crédito");
        System.out.println("2. Boleto Bancário");
        System.out.println("3. Pix");
        System.out.print("Escolha o método de pagamento: ");
        int opcao = scanner.nextInt();
        scanner.nextLine();

        switch (opcao) {
            case 1:
                System.out.print("Digite o número de parcelas (1 a 4): ");
                int parcelas = scanner.nextInt();
                scanner.nextLine();

                if (parcelas >= 1 && parcelas <= 4) {
                    double valorParcela = total / parcelas;
                    System.out.printf("Pagamento em %dx de R$%.2f processado com sucesso!\n", parcelas, valorParcela);
                } else {
                    System.out.println("Número de parcelas inválido. Pagamento será feito em 1x.");
                    System.out.printf("Pagamento em 1x de R$%.2f processado com sucesso!\n", total);
                }
                break;
            case 2:
                System.out.println("Boleto gerado. Aguarde a confirmação do pagamento.");
                break;
            case 3:
                System.out.println("Chave pix: 31998216708");
                break;
            default:
                System.out.println("Opção inválida.");
        }
    }

    public static void salvarHistoricoEmArquivo() {
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("historico.txt")))) {
            for (Pedido pedido : historicoPedidos) {
                pw.println("Pedido " + pedido.getId() + " - Cliente: " + pedido.getCliente().getNome());
                for (ItemCar item : pedido.getItens()) {
                    pw.println(item.getTenis().getNome() + ";" + item.getTamanho() + ";" + item.getQuantidade() + ";" + item.getTenis().getPreco());
                }
                pw.println("Total;" + pedido.getTotal());
                pw.println("----");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

// Versão simplificada para interface de texto
public static void finalizarPedido() {
    if (clienteLogado == null || carrinho.isEmpty()) {
        System.out.println("Faça login e adicione produtos ao carrinho.");
        return;
    }

    double total = 0;
    for (ItemCar item : carrinho) {
        item.getTenis().atualizarEstoque(item.getQuantidade());
        total += item.getSubtotal();
    }

    Pedido pedido = new Pedido(clienteLogado, new ArrayList<>(carrinho));
    clienteLogado.adicionarPedido(pedido);
    historicoPedidos.add(pedido);

    // Chama o método que pergunta pelo método de pagamento no console
    selecionarMetodoPagamento(total);

    carrinho.clear();
    System.out.println("\nPedido finalizado com sucesso!\n" + pedido);
    new view.TelaHistoricoPedidos().setVisible(true);
}

// Versão usada pela interface gráfica (com método e parcelas)
public static void finalizarPedido(String metodo) {
    finalizarPedido(metodo, 1); // padrão: 1 parcela
}

public static void finalizarPedido(String metodo, int parcelas) {
    if (clienteLogado == null || carrinho.isEmpty()) {
        System.out.println("Faça login e adicione produtos ao carrinho.");
        return;
    }

    double total = 0;
    for (ItemCar item : carrinho) {
        item.getTenis().atualizarEstoque(item.getQuantidade());
        total += item.getSubtotal();
    }

    Pedido pedido = new Pedido(clienteLogado, new ArrayList<>(carrinho));
    clienteLogado.adicionarPedido(pedido);
    historicoPedidos.add(pedido);

    // Simula processamento do pagamento
    switch (metodo.toLowerCase()) {
        case "pix":
            System.out.println("Chave pix: 31998216708");
            break;
        case "boleto":
            System.out.println("Boleto gerado. Aguarde confirmação.");
            break;
        case "cartao":
            if (parcelas < 1 || parcelas > 4) parcelas = 1;
            double valorParcela = total / parcelas;
            System.out.printf("Pagamento em %dx de R$%.2f realizado!\n", parcelas, valorParcela);
            break;
        default:
            System.out.println("Método de pagamento inválido.");
    }

    System.out.println("Carrinho antes: " + carrinho.size());
carrinho.clear();
System.out.println("Carrinho depois: " + carrinho.size());

    System.out.println("Pedido finalizado: " + pedido);
}

    
    // Mostra o histórico de compras do cliente logado
    static void verHistorico() {
        if (clienteLogado == null) {
            System.out.println("Faça login para visualizar seu histórico.");
            return;
        }

        System.out.println("\n--- HISTÓRICO DE PEDIDOS ---");
        if (clienteLogado.getHistorico().isEmpty()) {
            System.out.println("Nenhum pedido encontrado.");
        } else {
            for (Pedido pedido : clienteLogado.getHistorico()) {
                System.out.println(pedido);
                System.out.println();
            }
        }
    }

    // Menu exclusivo para administradores
    static void menuAdmin() {
        while (true) {
            System.out.println("\n--- MENU ADMIN ---");
            System.out.println("1. Editar Descrição");
            System.out.println("2. Editar Preço");
            System.out.println("3. Editar Estoque");
            System.out.println("4. Voltar");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    editarDescricao();
                    break;
                case 2:
                    editarPreco();
                    break;
                case 3:
                    editarEstoque();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
    
    // Salva os dados do estoque em um arquivo
public static void salvarEstoqueEmArquivo() {
    try (PrintWriter writer = new PrintWriter("estoque.txt")) {
        for (Tenis t : estoqueTenis) {
            writer.println(t.getId() + ";" + t.getModelo() + ";" + t.getMarca() + ";" + t.getPreco() + ";" + t.getEstoque());
        }
    } catch (Exception e) {
        System.out.println("Erro ao salvar o estoque: " + e.getMessage());
    }
}

// Carrega os dados do estoque de um arquivo
    public static void carregarEstoqueDoArquivo() {
    estoqueTenis.clear();
    try (BufferedReader reader = new BufferedReader(new FileReader("estoque.txt"))) {
        String linha;
        while ((linha = reader.readLine()) != null) {
            String[] partes = linha.split(";");
            if (partes.length == 5) {
                int id = Integer.parseInt(partes[0]);
                String modelo = partes[1];
                String marca = partes[2];
                double preco = Double.parseDouble(partes[3]);
                int estoque = Integer.parseInt(partes[4]);
                estoqueTenis.add(new Tenis(id, modelo, marca, preco, estoque));
        }   }
    } catch (FileNotFoundException e) {
        System.out.println("Arquivo de estoque não encontrado. Criando estoque padrão...");
        inicializarProdutos();
        salvarEstoqueEmArquivo(); // salva estoque inicial
    } catch (Exception e) {
        System.out.println("Erro ao carregar o estoque: " + e.getMessage());
    }
    }

    // Funções para permitir ao admin editar os dados dos produtos

    static void editarDescricao() {
        listarTenis();
        System.out.print("Digite o ID do tênis para editar a descrição: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Novo Modelo: ");
                String desc = scanner.nextLine();
                t.setModelo(desc);
                System.out.println("Modelo atualizado.");
                salvarEstoqueEmArquivo(); // salva
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }

    static void editarPreco() {
        listarTenis();
        System.out.print("Digite o ID do tênis para editar o preço: ");
        int id = scanner.nextInt();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Novo preço: ");
                double preco = scanner.nextDouble();
                t.setPreco(preco);
                System.out.println("Preço atualizado.");
                salvarEstoqueEmArquivo();
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }

    static void editarEstoque() {
        listarTenis();
        System.out.print("Digite o ID do tênis para editar o estoque: ");
        int id = scanner.nextInt();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Novo estoque: ");
                int novoEstoque = scanner.nextInt();
                t.setEstoque(novoEstoque);
                System.out.println("Estoque atualizado.");
                salvarEstoqueEmArquivo();
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }
}
