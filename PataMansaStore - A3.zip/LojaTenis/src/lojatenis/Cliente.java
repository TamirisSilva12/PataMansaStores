package lojatenis;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
    // Atributos básicos do cliente
    private int id;
    private String nome;
    private String email;
    private String senha;
    private boolean admin; // Indica se o cliente é um administrador
    private List<Pedido> historico; // Guarda o histórico de pedidos do cliente

    // Construtor completo: recebe todas as informações, incluindo se é admin ou não
    public Cliente(int id, String nome, String email, String senha, boolean admin) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.admin = admin;
        this.historico = new ArrayList<>(); // Inicializa o histórico como uma lista vazia
    }

    // Construtor alternativo: não recebe o admin, assume que é false (cliente comum)
    public Cliente(int id, String nome, String email, String senha, String endereco) {
        this(id, nome, email, senha, false); // Chama o outro construtor passando false para admin
    }

    // Construtor usado quando ainda não temos o ID (por exemplo, cadastro novo)
    public Cliente(String nome, String email, String senha, boolean admin) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.admin = admin;
        this.historico = new ArrayList<>();
    }
    @Override
    public String toString() {
        return id + ";" + nome + ";" + email + ";" + (admin ? "1" : "0");
    }

    // Retorna se o cliente é admin
    public boolean isAdmin() {
        return admin;
    }

    // Retorna o email do cliente
    public String getEmail() {
        return email;
    }

    // Retorna o nome do cliente
    public String getNome() {
        return nome;
    }

    // Retorna o ID do cliente
    public int getId() {
        return id;
    }

    // Verifica se o email e senha informados batem com os do cliente (login)
    public boolean autenticar(String email, String senha) {
        return this.email.equals(email) && this.senha.equals(senha);
    }

    // Adiciona um pedido ao histórico do cliente
    public void adicionarPedido(Pedido pedido) {
        historico.add(pedido);
    }

    // Retorna a lista de pedidos feitos pelo cliente
    public List<Pedido> getHistorico() {
        return historico;
    }
}
