package lojatenis;

public class Tenis {
    private int id;
    private String modelo;
    private String marca;
    private double preco;
    private int estoque;
    private String descricao;
    private String caminhoFoto;



    public Tenis(int id, String modelo, String marca, double preco, int estoque) {
        this.id = id;
        this.modelo = modelo;
        this.marca = marca;
        this.preco = preco;
        this.estoque = estoque;
    }

    public int getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }

    public double getPreco() {
        return preco;
    }

    public int getEstoque() {
        return estoque;
    }
    
    public String getNome() {
        return marca + " " + modelo;
    }
    
    public void setCaminhoFoto(String caminho) {
        this.caminhoFoto = caminho;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setMarca(String marca) {
    this.marca = marca;
    }

    public void setPreco(double preco) {
    this.preco = preco;
    }

    public void setEstoque(int estoque) {
    this.estoque = estoque;
    }
    public void setDescricao(String descricao) {
    this.descricao = descricao;
    }



    // Verifica se há estoque suficiente
    public boolean temEstoque(int quantidade) {
        return estoque >= quantidade;
    }

    // Atualiza o estoque ao remover quantidade (ex: após uma compra)
    public void atualizarEstoque(int quantidade) {
        if (quantidade > 0 && quantidade <= estoque) {
            this.estoque -= quantidade;
        }
    }

    @Override
    public String toString() {
        return id + ": " + marca + " " + modelo + " - R$" + String.format("%.2f", preco)
               + " (Estoque: " + estoque + ")";
    }
}
