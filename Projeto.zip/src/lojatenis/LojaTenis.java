package lojatenis;

import java.util.*;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import java.io.File;
import java.nio.file.Path;

public class LojaTenis {
    // Scanner para ler entrada do usuário via console
    static Scanner scanner = new Scanner(System.in);
    // Lista que armazena os tênis disponíveis na loja
    static List<Tenis> estoqueTenis = new ArrayList<>();
    // Lista que armazena os clientes cadastrados
    static List<Cliente> clientes = new ArrayList<>();
    // Lista que armazena os usuários administradores
    static List<Cliente> admins = new ArrayList<>();
    // Cliente atualmente logado
    static Cliente clienteLogado = null;
    // Lista de itens no carrinho do cliente logado
    static List<ItemCar> carrinho = new ArrayList<>();

    public static void main(String[] args) {
        inicializarProdutos();   // Cria produtos e adiciona ao estoque
        inicializarAdmin();      // Cria administrador padrão
        System.out.println("Bem-vindo à Loja de Tênis Virtual!");
        menuPrincipal();         // Inicia o menu principal da aplicação
    }

    // Adiciona tênis ao estoque da loja
    static void inicializarProdutos() {
        estoqueTenis.add(new Tenis(1, "Nike Air Max", "Confortável e estiloso", 599.90, 10));
        estoqueTenis.add(new Tenis(2, "Adidas Ultraboost", "Alta performance para corrida", 649.90, 5));
        estoqueTenis.add(new Tenis(3, "Puma Flyer", "Design moderno para o dia a dia", 349.90, 8));
        estoqueTenis.add(new Tenis(4, "Asics Gel", "Ideal para treinos intensos", 429.90, 6));
        estoqueTenis.add(new Tenis(5, "New Balance 574", "Casual e durável", 389.90, 4));
    }

    // Cria um usuário administrador com dados fixos
    static void inicializarAdmin() {
        admins.add(new Cliente(0, "Administrador", "Admin@loja.com", "#AdminTK", "Loja Central"));
    }

    // Menu principal da loja com opções para o usuário
    static void menuPrincipal() {
        while (true) {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Login");
            System.out.println("3. Ver Tênis Disponíveis");
            System.out.println("4. Adicionar ao Carrinho");
            System.out.println("5. Ver Carrinho");
            System.out.println("6. Finalizar Pedido");
            System.out.println("7. Ver Histórico de Pedidos");
            System.out.println("8. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa buffer

            switch (opcao) {
                case 1:
                    cadastrarCliente(); // Cadastra novo cliente
                    break;
                case 2:
                    login(); // Realiza login de cliente ou admin
                    break;
                case 3:
                    listarTenis(); // Mostra tênis disponíveis no estoque
                    break;
                case 4:
                    adicionarAoCarrinho(); // Adiciona tênis ao carrinho do cliente logado
                    break;
                case 5:
                    verCarrinho(); // Mostra itens do carrinho
                    break;
                case 6:
                    finalizarPedido(); // Finaliza compra e faz pagamento
                    break;
                case 7:
                    verHistorico(); // Mostra histórico de pedidos do cliente logado
                    break;
                case 8:
                    System.out.println("Obrigado por visitar a Loja de Tênis!");
                    return; // Sai do programa
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    // Realiza o login de um cliente ou administrador
    static void login() {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();

        // Verifica se é administrador
        for (Cliente a : admins) {
            if (a.autenticar(email, senha)) {
                System.out.println("Login de administrador realizado com sucesso.");
                menuAdmin(); // Abre menu admin
                return;
            }
        }

        // Verifica se é cliente comum
        for (Cliente c : clientes) {
            if (c.autenticar(email, senha)) {
                clienteLogado = c; // Define cliente logado
                System.out.println("Login realizado com sucesso. Bem-vindo, " + c.getNome() + "!");
                return;
            }
        }

        System.out.println("Email ou senha inválidos."); // Login falhou
    }

    // Cadastra um novo cliente na loja
    static void cadastrarCliente() {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();

        int id = clientes.size() + 1; // Gera ID incremental
        clientes.add(new Cliente(id, nome, email, senha, endereco));
        System.out.println("Cadastro realizado com sucesso!");
    }

    // Lista todos os tênis disponíveis no estoque
    static void listarTenis() {
        System.out.println("\n--- TÊNIS DISPONÍVEIS ---");
        for (Tenis t : estoqueTenis) {
            System.out.println(t); // Exibe dados do tênis (toString)
        }
    }

    // Adiciona tênis ao carrinho do cliente logado
    static void adicionarAoCarrinho() {
        if (clienteLogado == null) {
            System.out.println("Você precisa estar logado para adicionar ao carrinho.");
            return;
        }

        listarTenis(); // Mostra tênis para escolher
        System.out.print("Digite o ID do tênis desejado: ");
        int id = scanner.nextInt();
        System.out.print("Quantidade: ");
        int qtd = scanner.nextInt();
        System.out.print("Tamanho (ex: 38, 39, 40...): ");
        int tamanho = scanner.nextInt();
        scanner.nextLine(); // Limpa buffer

        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                if (t.temEstoque(qtd)) { // Verifica estoque suficiente
                    carrinho.add(new ItemCar(t, qtd, tamanho)); // Adiciona ao carrinho
                    System.out.println("Tênis adicionado ao carrinho (Tamanho: " + tamanho + ").");
                } else {
                    System.out.println("Estoque insuficiente.");
                }
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }

    // Exibe os itens adicionados ao carrinho e o total
    static void verCarrinho() {
        if (carrinho.isEmpty()) {
            System.out.println("Carrinho vazio.");
            return;
        }

        System.out.println("\n--- CARRINHO ---");
        double total = 0;
        for (ItemCar item : carrinho) {
            System.out.println(item); // Exibe cada item (toString)
            total += item.getSubtotal(); // Soma subtotal
        }
        System.out.println("Total: R$" + String.format("%.2f", total));
    }

    // Método para seleção do pagamento e processa o método escolhido
    static void selecionarMetodoPagamento(double total) {
        System.out.println("\n--- MÉTODO DE PAGAMENTO ---");
        System.out.println("1. Cartão de Crédito");
        System.out.println("2. Boleto Bancário");
        System.out.println("3. Pix");
        System.out.print("Escolha o método de pagamento: ");
        int opcao = scanner.nextInt();
        scanner.nextLine();

        switch (opcao) {
            case 1:
                System.out.print("Digite o número de parcelas (1 a 4): ");
                int parcelas = scanner.nextInt();
                scanner.nextLine();

                if (parcelas >= 1 && parcelas <= 4) {
                    double valorParcela = total / parcelas;
                    System.out.printf("Pagamento em %dx de R$%.2f processado com sucesso!\n", parcelas, valorParcela);
                } else {
                    System.out.println("Número de parcelas inválido. Pagamento será feito em 1x.");
                    System.out.printf("Pagamento em 1x de R$%.2f processado com sucesso!\n", total);
                }
                break;
            case 2:
                System.out.println("Boleto gerado. Aguarde a confirmação do pagamento.");
                break;
            case 3:
                gerarQRCodePix(total); // Gera QR Code Pix para pagamento
                break;
            default:
                System.out.println("Opção inválida.");
        }
    }

    // Finaliza o pedido, atualiza estoque, adiciona pedido ao histórico e limpa o carrinho
    static void finalizarPedido() {
        if (clienteLogado == null) {
            System.out.println("Faça login para finalizar o pedido.");
            return;
        }
        if (carrinho.isEmpty()) {
            System.out.println("Carrinho vazio.");
            return;
        }

        double total = 0;
        for (ItemCar item : carrinho) {
            item.getTenis().atualizarEstoque(item.getQuantidade()); // Atualiza estoque reduzindo quantidade vendida
            total += item.getSubtotal(); // Soma o total do pedido
        }

        Pedido pedido = new Pedido(clienteLogado, new ArrayList<>(carrinho)); // Cria objeto pedido
        clienteLogado.adicionarPedido(pedido); // Adiciona pedido ao histórico do cliente
        selecionarMetodoPagamento(total);       // Solicita pagamento

        carrinho.clear(); // Limpa carrinho após finalizar compra
        System.out.println("\nPedido finalizado com sucesso!\n" + pedido);
    }

    // Exibe o histórico de pedidos do cliente logado
    static void verHistorico() {
        if (clienteLogado == null) {
            System.out.println("Faça login para visualizar seu histórico.");
            return;
        }

        System.out.println("\n--- HISTÓRICO DE PEDIDOS ---");
        if (clienteLogado.getHistorico().isEmpty()) {
            System.out.println("Nenhum pedido encontrado.");
        } else {
            for (Pedido pedido : clienteLogado.getHistorico()) {
                System.out.println(pedido);
                System.out.println();
            }
        }
    }

    // Gera um QR Code para pagamento via Pix usando biblioteca ZXing
    static void gerarQRCodePix(double valor) {
        try {
            // Conteúdo simulado para Pix
            String conteudo = "pix:chavePixExemplo@provedor.com|valor=" + valor;
            int tamanho = 300;

            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(conteudo, BarcodeFormat.QR_CODE, tamanho, tamanho);

            Path caminho = new File("qrcode_pix.png").toPath();
            MatrixToImageWriter.writeToPath(bitMatrix, "PNG", caminho);

            System.out.println("QR Code Pix gerado com sucesso! Arquivo: qrcode_pix.png");
        } catch (Exception e) {
            System.out.println("Erro ao gerar QR Code Pix: " + e.getMessage());
        }
    }

    // Menu específico para administradores, com opções para editar produtos
    static void menuAdmin() {
        while (true) {
            System.out.println("\n--- MENU ADMIN ---");
            System.out.println("1. Editar Descrição");
            System.out.println("2. Editar Preço");
            System.out.println("3. Editar Estoque");
            System.out.println("4. Editar Foto");
            System.out.println("5. Voltar");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    editarDescricao();
                    break;
                case 2:
                    editarPreco();
                    break;
                case 3:
                    editarEstoque();
                    break;
                case 4:
                    editarFoto();
                    break;
                case 5:
                    return; // Sai do menu admin e volta ao menu principal
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    // Permite ao admin editar a descrição de um tênis
    static void editarDescricao() {
        listarTenis();
        System.out.print("Digite o ID do tênis para editar a descrição: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Nova descrição: ");
                String desc = scanner.nextLine();
                t.setDescricao(desc);
                System.out.println("Descrição atualizada.");
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }

    // Permite ao admin editar o preço de um tênis
    static void editarPreco() {
        listarTenis();
        System.out.print("Digite o ID do tênis para editar o preço: ");
        int id = scanner.nextInt();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Novo preço: ");
                double preco = scanner.nextDouble();
                t.setPreco(preco);
                System.out.println("Preço atualizado.");
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }

    // Permite ao admin editar a quantidade em estoque de um tênis
    static void editarEstoque() {
        listarTenis();
        System.out.print("Digite o ID do tênis para editar o estoque: ");
        int id = scanner.nextInt();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Novo estoque: ");
                int novoEstoque = scanner.nextInt();
                t.setEstoque(novoEstoque);
                System.out.println("Estoque atualizado.");
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }

    // Permite ao admin alterar o caminho da foto do tênis (simulado)
    static void editarFoto() {
        listarTenis();
        System.out.print("Digite o ID do tênis para alterar a 'foto': ");
        int id = scanner.nextInt();
        scanner.nextLine();
        for (Tenis t : estoqueTenis) {
            if (t.getId() == id) {
                System.out.print("Novo caminho da foto: ");
                String caminhoFoto = scanner.nextLine();
                t.setCaminhoFoto(caminhoFoto);
                System.out.println("Foto atualizada.");
                return;
            }
        }
        System.out.println("Tênis não encontrado.");
    }
}
