package lojatenis;

public class ItemCar {
    private Tenis tenis;
    private int quantidade;
    private int tamanho; // <-- novo campo

    public ItemCar(Tenis tenis, int quantidade, int tamanho) {
        this.tenis = tenis;
        this.quantidade = quantidade;
        this.tamanho = tamanho;
    }

    public Tenis getTenis() {
        return tenis;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public int getTamanho() {
        return tamanho;
    }

    public double getSubtotal() {
        return quantidade * tenis.getPreco();
    }

    @Override
    public String toString() {
        return tenis.getNome() + " (Tam: " + tamanho + ") x" + quantidade + " = R$" + String.format("%.2f", getSubtotal());
    }
}
