package lojatenis;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private int id;
    private String nome;
    private String email;
    private String senha;
    private String endereco;
    private boolean admin;
    private List<Pedido> historico;

    // Construtor completo com admin
    public Cliente(int id, String nome, String email, String senha, String endereco, boolean admin) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.endereco = endereco;
        this.admin = admin;
        this.historico = new ArrayList<>();
    }

    // Construtor sem admin, assume false
    public Cliente(int id, String nome, String email, String senha, String endereco) {
        this(id, nome, email, senha, endereco, false);
    }

    // Se precisar criar cliente com só nome, email, senha e admin (sem id e endereço)
    // - opcional, depende do seu uso
    public Cliente(String nome, String email, String senha, boolean admin) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.admin = admin;
        this.historico = new ArrayList<>();
    }

    public boolean isAdmin() {
        return admin;
    }

    public String getEmail() {
        return email;
    }

    public String getNome() {
        return nome;
    }

    public int getId() {
        return id;
    }

    public String getEndereco() {
        return endereco;
    }

    // Autenticação pelo email e senha
    public boolean autenticar(String email, String senha) {
        return this.email.equals(email) && this.senha.equals(senha);
    }

    // Adiciona pedido ao histórico
    public void adicionarPedido(Pedido pedido) {
        historico.add(pedido);
    }

    // Retorna o histórico de pedidos
    public List<Pedido> getHistorico() {
        return historico;
    }
}
