package lojatenis;

import java.util.List;

public class Pedido {
    private static int contador = 1; // Contador estático para gerar IDs únicos
    private int id;
    private Cliente cliente;
    private List<ItemCar> itens;
    private double total;

    public Pedido(Cliente cliente, List<ItemCar> itens) {
        this.id = contador++;
        this.cliente = cliente;
        this.itens = itens;
        this.total = calcularTotal();
    }

    // Soma os subtotais dos itens do pedido
    private double calcularTotal() {
        double soma = 0;
        for (ItemCar item : itens) {
            soma += item.getSubtotal();
        }
        return soma;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido ").append(id).append(" - Cliente: ").append(cliente.getNome()).append("\n");
        for (ItemCar item : itens) {
            sb.append("  ").append(item).append("\n");
        }
        sb.append("Total: R$").append(String.format("%.2f", total));
        return sb.toString();
    }
}
